sap.ui.define(["sap/uxap/BlockBase"], function (BlockBase) {
	"use strict";

	var BlockAdresses = BlockBase.extend("employeeprofile.SharedBlocks.personal.BlockAdresses", {
		metadata: {}
	});
	return BlockAdresses;
});